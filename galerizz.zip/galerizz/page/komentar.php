<?php 
$fotoid=@$_GET["id"];
$userid=@$_SESSION["userid"];
$komentarfotoid=@$_GET['komentarfoto_id'];
$cek=mysqli_num_rows(mysqli_query($conn, "SELECT * FROM komentarfoto WHERE UserID='$userid' AND FotoID='$fotoid' AND komentarfotoID='$komentarfotoid'"));
if ($cek > 0) {
   $delete=mysqli_query($conn, "DELETE FROM komentarfoto WHERE komentarfotoID='$komentarfotoid'");
   echo '<script>alert("Anda berhasil menghapus komentarfoto ini");</script>';
   echo '<meta http-equiv="refresh" content="0; url=?url=detail&&id='.@$fotoid.'">';
} else {
   // User is not allowed to delete the comment
   $alert='Gagal hapus komentarfoto';
   echo '<script>alert("Anda tidak berhak menghapus komentarfoto ini");</script>';
   echo '<meta http-equiv="refresh" content="0; url=?url=detail&&id='.@$fotoid.'">';
}
?>
