-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 02 Mar 2024 pada 04.59
-- Versi server: 10.4.28-MariaDB
-- Versi PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gallery`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `album`
--

CREATE TABLE `album` (
  `albumid` int(11) NOT NULL,
  `namaalbum` varchar(255) NOT NULL,
  `deskripsi` text NOT NULL,
  `tanggaldibuat` date NOT NULL,
  `userid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `album`
--

INSERT INTO `album` (`albumid`, `namaalbum`, `deskripsi`, `tanggaldibuat`, `userid`) VALUES
(1, 'PARTAI', 'Partai 2024', '2024-02-05', 1),
(2, 'CAPRES', 'Capres 2024', '2024-02-05', 1),
(3, 'CALEG DPRD', 'Caleg DPRD 2024', '2024-02-29', 1),
(4, 'CALEG DPR RI', 'Caleg DPR RI 2024', '2024-02-29', 1),
(5, 'CALEG DMLN', 'Caleg Dapil Masyarakat Luar Negeri 2024', '2024-02-29', 1),
(6, 'CALEG DPD RI', 'Caleg DPD RI 2024', '2024-03-02', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `foto`
--

CREATE TABLE `foto` (
  `fotoid` int(11) NOT NULL,
  `judulfoto` varchar(255) NOT NULL,
  `deskripsifoto` text NOT NULL,
  `tanggalunggah` date NOT NULL,
  `lokasifile` varchar(255) NOT NULL,
  `albumid` int(11) NOT NULL,
  `userid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `foto`
--

INSERT INTO `foto` (`fotoid`, `judulfoto`, `deskripsifoto`, `tanggalunggah`, `lokasifile`, `albumid`, `userid`) VALUES
(3, 'Partai Puki', 'KOalisi troNjal TronjOL MAha aSyik', '2024-03-02', 'Partai Puki1.jpg', 1, 1),
(4, 'nurhaDI aLDO', 'Nurhadi–Aldo (disingkat Dildo) adalah pasangan calon pemilihan presiden fiktif dengan nomor urut 10 yang dibuat oleh sekelompok anak muda, tersebar di berbagai kota di Indonesia. Nurhadi sendiri merupakan seorang tokoh yang berprofesi sebagai tukang pijat, sedangkan Aldo adalah tokoh fiktif yang cukup viral di media sosial karena unggahannya. Partai yang mengusung paslon ini juga fiktif yaitu Partai Untuk Kebutuhan Iman (PUKI) dan membentuk Koalisi Indonesia Tronjal-Tronjol Maha Asyik.\r\nCoblos Capres dan Cawapres Nomer 10!!!', '2024-02-29', 'Nurhadi Aldo.jpg', 2, 1),
(5, 'SHOHIH FEBRIANSYAH, S.Pd', 'Luar biasa sekali, Caleg ini menuju kesempurnaan-nya Andra and The Backbone. Silahkan pilih kalau kamu tipikal orang yang perfectionist.', '2024-02-29', 'CalegDPRD.jpg', 3, 1),
(6, 'DICKI MAHARDIKA', 'Sosok yang ada di bawah ini tentu tak asing lagi. Pentolan grup band Olski yang lagi hits ini sedang mencoba peruntungannya di kancah perpolitikan yang terkenal asyik menggelitik. Hmmm…sudah bosan band-band-nan ya mas?', '2024-02-29', 'DickiMahardika.jpg', 3, 1),
(7, 'HAWIN WIDYO S.PH', 'Para pejuang LDR se-Indonesia Raya…bersatulah!!!! ', '2024-02-29', 'HAWINWIDYO.jpg', 4, 1),
(8, 'HISDAN SATRIA S.Kom.l', 'Setuju banget sama program kerja nomer 3! Bayarnya banyak banget, sebulan jadian sudah diputusin. Rugi bandar atuhhh…', '2024-02-29', 'HISDANSATRIA.jpg', 3, 1),
(9, 'ADI BIMANTORO S.Pd', 'Jujur sekali Caleg yang satu ini. Saat kebanyakan Caleg profesional membuat program kerja ndakik-ndakik yang ternyata ujung-ujungnya korupsi untuk memperkaya diri, Caleg dari partai PUKI ini justru berkata jujur untuk “meningkatkan” rumah sendiri. Salut pak!!!', '2024-02-29', 'ADIBIMANTORO.jpg', 3, 1),
(10, 'PROF. R. PRABOWO YOGA, S.Si., J.An., c.UK.', 'Beragam isu SARA memang memecah belah kesatuan bangsa. Tapi isu SARU kebanyakan justru mempersatukan semua golongan. Tak percaya? Silahkan cek sendiri ke tekape.', '2024-02-29', 'PROFRPRABOWOYOGA.jpg', 4, 1),
(11, 'WAFI RAJUNALLAH', 'Programnya sih memberikan tips PDKT yang ampuh dan terpercaya. Tapi kok penampilannya kaya gak bisa dipercaya gitu ya?', '2024-02-29', 'WAFIRAJUNALLAH.jpg', 5, 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `komentarfoto`
--

CREATE TABLE `komentarfoto` (
  `komentarid` int(11) NOT NULL,
  `fotoid` int(11) DEFAULT NULL,
  `userid` int(11) DEFAULT NULL,
  `komentar` text DEFAULT NULL,
  `tanggal` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `komentarfoto`
--

INSERT INTO `komentarfoto` (`komentarid`, `fotoid`, `userid`, `komentar`, `tanggal`) VALUES
(1, 3, 1, 'hahaha', '2024-02-27 17:00:00'),
(2, 4, 1, 'wkwkkw', '2024-02-27 17:00:00');

-- --------------------------------------------------------

--
-- Struktur dari tabel `likefoto`
--

CREATE TABLE `likefoto` (
  `likeid` int(11) NOT NULL,
  `fotoid` int(11) DEFAULT NULL,
  `userid` int(11) DEFAULT NULL,
  `tanggallike` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `likefoto`
--

INSERT INTO `likefoto` (`likeid`, `fotoid`, `userid`, `tanggallike`) VALUES
(8, 4, 1, '2024-02-29');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `userid` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `namalengkap` varchar(255) NOT NULL,
  `alamat` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`userid`, `username`, `password`, `email`, `namalengkap`, `alamat`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'user1@gmail.com', 'Admin 01', 'pelem'),
(2, 'user', 'ee11cbb19052e40b07aac0ca060c23ee', 'user1@gmail.com', 'User 01', 'Ahihihi');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `album`
--
ALTER TABLE `album`
  ADD PRIMARY KEY (`albumid`),
  ADD KEY `userid` (`userid`);

--
-- Indeks untuk tabel `foto`
--
ALTER TABLE `foto`
  ADD PRIMARY KEY (`fotoid`),
  ADD KEY `albumid` (`albumid`),
  ADD KEY `userid` (`userid`);

--
-- Indeks untuk tabel `komentarfoto`
--
ALTER TABLE `komentarfoto`
  ADD PRIMARY KEY (`komentarid`),
  ADD KEY `fotoid` (`fotoid`),
  ADD KEY `userid` (`userid`);

--
-- Indeks untuk tabel `likefoto`
--
ALTER TABLE `likefoto`
  ADD PRIMARY KEY (`likeid`),
  ADD KEY `fotoid` (`fotoid`),
  ADD KEY `userid` (`userid`);

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`userid`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `album`
--
ALTER TABLE `album`
  MODIFY `albumid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT untuk tabel `foto`
--
ALTER TABLE `foto`
  MODIFY `fotoid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT untuk tabel `komentarfoto`
--
ALTER TABLE `komentarfoto`
  MODIFY `komentarid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `likefoto`
--
ALTER TABLE `likefoto`
  MODIFY `likeid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT untuk tabel `user`
--
ALTER TABLE `user`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `album`
--
ALTER TABLE `album`
  ADD CONSTRAINT `album_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `user` (`userid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `foto`
--
ALTER TABLE `foto`
  ADD CONSTRAINT `foto_ibfk_1` FOREIGN KEY (`albumid`) REFERENCES `album` (`albumid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `foto_ibfk_2` FOREIGN KEY (`userid`) REFERENCES `user` (`userid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `komentarfoto`
--
ALTER TABLE `komentarfoto`
  ADD CONSTRAINT `komentarfoto_ibfk_1` FOREIGN KEY (`fotoid`) REFERENCES `foto` (`fotoid`),
  ADD CONSTRAINT `komentarfoto_ibfk_2` FOREIGN KEY (`userid`) REFERENCES `user` (`userid`);

--
-- Ketidakleluasaan untuk tabel `likefoto`
--
ALTER TABLE `likefoto`
  ADD CONSTRAINT `likefoto_ibfk_1` FOREIGN KEY (`fotoid`) REFERENCES `foto` (`fotoid`),
  ADD CONSTRAINT `likefoto_ibfk_2` FOREIGN KEY (`userid`) REFERENCES `user` (`userid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
